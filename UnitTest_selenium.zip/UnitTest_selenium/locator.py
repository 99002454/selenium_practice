from selenium.webdriver.common.by import By

class MainPageLocator(object):
    Go_Button=(By.ID,"submit")

class SearchResultsPageLocator(object):
    pass