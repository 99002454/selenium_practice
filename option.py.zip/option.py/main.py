from selenium.webdriver.chrome.webdriver import WebDriver
from selenium import webdriver
import time

driver = webdriver.Chrome("C:\\driver\\chromedriver_win32\\chromedriver.exe")
driver.get("http://www.google.com")
driver.find_element_by_name("q").send_keys('Songs')

optionList = driver.find_elements_by_css_selector('ul.erkvQe li span')
print(len(optionList))

for ele in optionList:
    print(ele.text)

    # if ele.text=="Song":
    #     ele.click()
    #     break

print(driver.title)

time.sleep(5)
driver.quit()
