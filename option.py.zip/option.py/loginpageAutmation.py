import getpass

from pip._vendor.distlib.compat import raw_input
from selenium import webdriver
from getpass import getpass

username = 'standard_user'
password ='secret_sauce'

driver = webdriver.Chrome("C:\\driver\\chromedriver_win32\\chromedriver.exe")
driver.get("https://www.saucedemo.com/")

UserName = driver.find_element_by_id("user-name")
UserName.send_keys(username)
#UserName=driver.find_element_by_css_selector("css-1dbjc4n r-18u37iz r-ou255f")

Password = driver.find_element_by_id("password")
Password.send_keys(password)

login_button = driver.find_element_by_id("login-button")
login_button.submit()