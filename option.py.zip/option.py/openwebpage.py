#code to open python.org and seach through the search block

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from lib2to3.pgen2 import driver
options = webdriver.ChromeOptions()
options.add_experimental_option("useAutomationExtension", False)
options.add_experimental_option("excludeSwitches",["enable-automation"])
driver = webdriver.Chrome("C:\driver\chromedriver_win32/chromedriver.exe")
driver_path = 'C:\driver\chromedriver_win32\chromedriver.exe'



driver.get("https://www.python.org")
print(driver.title)
search_bar = driver.find_element_by_name("q")
search_bar.clear()
search_bar.send_keys("getting started with python")
search_bar.send_keys(Keys.RETURN)
print(driver.current_url)
time.sleep(5)
driver.close()