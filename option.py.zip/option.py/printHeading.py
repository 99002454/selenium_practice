# this program is to print the header pf the article
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome("C:\driver\chromedriver_win32/chromedriver.exe")
driver.get("https://www.python.org/")
print(driver.title)

search = driver.find_element_by_name('q')
search.send_keys('pointer')
search.send_keys(Keys.RETURN)

print(driver.page_source)

driver.quit()
