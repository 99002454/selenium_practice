import unittest
from selenium import webdriver
import page

class PythonOrgSearch(unittest.TestCase):

    def setUp(self):
        self.driver=webdriver.Chrome("C:\driver\chromedriver_win32/chromedriver.exe")
        self.driver.get("https://python.org")

    def test_example(self):
        print("Test")
        assert True

    def teardown(self):
        self.driver.close()

if __name__=="__main__":
    unittest.main()